

DROP TABLE Users;

DROP TABLE Orders;

DROP TABLE Product;

DROP TABLE Orders_product;