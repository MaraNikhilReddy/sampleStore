import exp from "constants";
import { order, orderStore } from "../../models/order";



const store=new orderStore();
describe("order table",()=>{
    const test1:order={
        // id:1,
        quantity:6,
        user_id:1,
        status:"active",
    }
    it("check create",async()=>{
        const newOne=await store.create(test1);
        const data={
            // id:1,
            quantity:newOne.quantity,
            user_id:newOne.user_id,
            status:newOne.status,
        }
        expect(data).toEqual(test1);
    })

    it("check function",()=>{
        expect(store.index).toBeDefined();
    })

    it("check index",async ()=>{
        const temp=await store.index();
        const test1:order={
            quantity:6,
            user_id:1,
            status:"active",
        }
        expect(temp[0].quantity).toEqual(test1.quantity)
    })

    it("check show",async ()=>{
        const temp=await store.show("1");
        if(temp){
            expect(temp[0].user_id).toEqual(test1.user_id);
        }
    })
})