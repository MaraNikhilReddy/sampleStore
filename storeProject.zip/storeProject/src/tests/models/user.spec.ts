import { UsersStore,User, showUser } from "../../models/user";


const store=new UsersStore();
// console.log("in testing phase");
describe("user table",()=>{
    const test1:User={
        first_name:"mara",
        last_name:"nikhil",
        user_name:"dev_user",
        password:"password123"
    }
    it("create user",async()=>{
        const expected_ans={
            id:1 as number,
            first_name:"mara",
            last_name:"nikhil",
            user_name:"dev_user",
            // password:"password123"
        }
        const data=await store.create(test1)
        const returned_ans={
            id:data.id,
            first_name:data.first_name,
            last_name:data.last_name,
            user_name:data.user_name
        }
        expect(returned_ans.first_name).toEqual(expected_ans.first_name);
    })
})